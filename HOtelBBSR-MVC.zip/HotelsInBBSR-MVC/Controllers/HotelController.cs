﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HotelsInBBSR_MVC.Models;



namespace HotelsInBBSR_MVC.Controllers
{
    public class HotelController : Controller
    {
        // GET: Hotel
        public ActionResult Hotel()
        {
            return View();
        }

        public JsonResult GetHotels()
        {
            using (HotelsBBSREntities dc = new HotelsBBSREntities())
            {
                var hotels = dc.Hotels.OrderBy(x => x.HotelID).ToList();
                return Json(new { data = hotels }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult Save(int id)
        {
            using (HotelsBBSREntities dc = new HotelsBBSREntities())
            {
                var v = dc.Hotels.Where(x => x.HotelID == id).FirstOrDefault();
                return View(v);
            }
        }

        [HttpPost]
        public ActionResult Save(Hotel htl)
        {
            bool status = false;

            if (ModelState.IsValid)
            {
                using (HotelsBBSREntities dc = new HotelsBBSREntities())
                {
                    if (htl.HotelID > 0)
                    {
                        //Edit
                        var v = dc.Hotels.Where(x => x.HotelID == htl.HotelID).FirstOrDefault();
                        if (v != null)
                        {
                            v.Hotel_Name = htl.Hotel_Name;
                            v.Location = htl.Location;
                            v.Available_Room = htl.Available_Room;
                            v.Description = htl.Description;
                        }
                    }
                    else
                    {
                        //Save
                        dc.Hotels.Add(htl);
                    }
                    dc.SaveChanges();
                    status = true;
                }
               return new JsonResult { Data = new { status = status} };
            }
            else
            {
                return HttpNotFound();
            }

        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            using (HotelsBBSREntities dc = new HotelsBBSREntities())
            {
                var v = dc.Hotels.Where(x => x.HotelID == id).FirstOrDefault();
                if(v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }
            }
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteHotel(int id)
        {
            bool status = false;
            using (HotelsBBSREntities dc = new HotelsBBSREntities())
            {
                var v = dc.Hotels.Where(x => x.HotelID == id).FirstOrDefault();
                if (v != null)
                {
                    dc.Hotels.Remove(v);
                    dc.SaveChanges();
                    status = true;
                }
                else
                {
                    return HttpNotFound();
                }
            }
            return new JsonResult { Data = new { status = status } };
        }
    }
}