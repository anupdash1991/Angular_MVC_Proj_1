﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace HotelsInBBSR_MVC.Models
{
    [MetadataType(typeof(HotelMetadata))]
    public partial class HotelCls
    {

    }


    public class HotelMetadata
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "Provide Hotel Name")]
        public string Hotel_Name { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Provide Hotel Name")]
        public string Location { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Provide Hotel Name")]
        public string Available_Room { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Provide Hotel Name")]
        public string Description { get; set; }

    }
}